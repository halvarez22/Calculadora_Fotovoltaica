import React, { useState, useRef, useEffect } from 'react';
import { BillData, HistoryEntry } from './types';
import { extractBillData } from './services/geminiService';
import FileUpload from './components/FileUpload';
import BillDisplay from './components/BillDisplay';
import Loader from './components/Loader';
import ErrorDisplay from './components/ErrorDisplay';
import HistoryPanel from './components/HistoryPanel';
import { CfeIcon, GithubIcon, HistoryIcon } from './components/Icons';

interface UploadedImage {
  base64: string;
  mimeType: string;
}

function App() {
  const [billData, setBillData] = useState<BillData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [isHistoryVisible, setIsHistoryVisible] = useState(false);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    // Load history from localStorage on initial render
    try {
      const storedHistory = localStorage.getItem('billHistory');
      if (storedHistory) {
        setHistory(JSON.parse(storedHistory));
      }
    } catch (error) {
      console.error("Failed to load history from localStorage", error);
      setHistory([]);
    }
  }, []);
  
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const saveHistory = (newHistory: HistoryEntry[]) => {
    try {
      localStorage.setItem('billHistory', JSON.stringify(newHistory));
      setHistory(newHistory);
    } catch (error) {
      console.error("Failed to save history to localStorage", error);
    }
  };

  const handleExtract = async (front: UploadedImage, back: UploadedImage) => {
    setIsLoading(true);
    setError(null);
    setBillData(null);
    setProgress(0);

    intervalRef.current = window.setInterval(() => {
      setProgress(prev => {
        if (prev >= 95) {
          if (intervalRef.current) clearInterval(intervalRef.current);
          return 95;
        }
        if (prev < 60) return prev + 1;
        if (prev < 90) return prev + 0.5;
        return prev + 0.2;
      });
    }, 100);

    try {
      const data = await extractBillData({ front, back });
      
      const newEntry: HistoryEntry = {
        id: Date.now(),
        date: new Date().toLocaleString('es-MX'),
        customerName: data.customerInfo.find(i => i.key.toUpperCase().includes('NOMBRE'))?.value || 'N/A',
        serviceNumber: data.customerInfo.find(i => i.key.includes('NO. DE SERVICIO'))?.value || 'N/A',
        totalAmount: data.billingSummary.find(i => i.key.includes('TOTAL A PAGAR'))?.value || 'N/A',
        billingPeriod: data.billingSummary.find(i => i.key.includes('PERIODO FACTURADO'))?.value || 'N/A',
        fullData: data
      };
      saveHistory([newEntry, ...history]);

      if (intervalRef.current) clearInterval(intervalRef.current);
      setProgress(100);
      setTimeout(() => {
        setBillData(data);
        setIsLoading(false);
      }, 500);
    } catch (err) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setProgress(100);
      setTimeout(() => {
        if (err instanceof Error) {
            setError(err.message);
        } else {
            setError('Ocurrió un error desconocido. Por favor, inténtalo de nuevo.');
        }
        setIsLoading(false);
      }, 500);
    }
  };

  const handleReset = () => {
    setBillData(null);
    setError(null);
    setIsLoading(false);
    setProgress(0);
     if (intervalRef.current) {
        clearInterval(intervalRef.current);
     }
  };

  const handleViewHistoryEntry = (id: number) => {
    const entry = history.find(e => e.id === id);
    if (entry) {
        setBillData(entry.fullData);
        setError(null);
        setIsLoading(false);
        setIsHistoryVisible(false); // Close panel on selection
    }
  };

  const handleClearHistory = () => {
    if (window.confirm('¿Estás seguro de que quieres borrar todo el historial? Esta acción no se puede deshacer.')) {
        saveHistory([]);
    }
  };

  const renderContent = () => {
    if (isLoading) {
      return <Loader progress={progress} />;
    }
    if (error) {
      return <ErrorDisplay message={error} onRetry={handleReset} />;
    }
    if (billData) {
      return <BillDisplay data={billData} />;
    }
    return <FileUpload onExtract={handleExtract} />;
  };

  return (
    <div className="bg-black min-h-screen font-sans text-gray-200 antialiased flex flex-col">
      <header className="bg-gray-900 shadow-lg shadow-yellow-500/10 sticky top-0 z-10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <CfeIcon className="h-8 w-8 text-yellow-500" />
              <h1 className="text-xl sm:text-2xl font-bold text-gray-100 tracking-tight">
                Analizador de Recibos CFE
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setIsHistoryVisible(true)}
                className="text-gray-400 hover:text-yellow-500"
                aria-label="Ver historial"
              >
                <HistoryIcon className="h-6 w-6" />
              </button>
              {billData && !isLoading && (
                <button
                  onClick={handleReset}
                  className="bg-yellow-500 text-black font-semibold px-4 py-2 rounded-md hover:bg-yellow-600 transition-colors duration-200 text-sm"
                >
                  Analizar Otro
                </button>
              )}
              <a href="https://github.com/google/gemini-api-cookbook" target="_blank" rel="noopener noreferrer" aria-label="Github Repository">
                 <GithubIcon className="h-6 w-6 text-gray-400 hover:text-yellow-500" />
              </a>
            </div>
          </div>
        </div>
      </header>
      <main className="container mx-auto p-4 sm:p-6 lg:p-8 flex-grow">
        {renderContent()}
      </main>
      <HistoryPanel
        isVisible={isHistoryVisible}
        history={history}
        onViewEntry={handleViewHistoryEntry}
        onClearHistory={handleClearHistory}
        onClose={() => setIsHistoryVisible(false)}
      />
      <footer className="text-center py-6">
        <p className="text-xs text-gray-500">
          Powered By pai-b (Your Private Artificial Intelligence For Business) © Todos los derechos Reservados 2025
        </p>
      </footer>
    </div>
  );
}

export default App;