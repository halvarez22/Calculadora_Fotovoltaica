import React from 'react';
import { BillData } from '../types';
import ConsumptionChart from './ConsumptionChart';
import DataSection from './DataSection';
import { UserIcon, InvoiceIcon, ChartIcon, TableIcon, WrenchIcon, MoneyIcon } from './Icons';

const BillDisplay: React.FC<{ data: BillData }> = ({ data }) => {
  const consumptionDetailsColumns = [
    { key: 'Concepto', label: 'Concepto' },
    { key: 'Medida', label: 'Medida' },
    { key: 'Precio (MXN)', label: 'Precio (MXN)' },
    { key: 'Subtotal (MXN)', label: 'Subtotal (MXN)' },
  ];

  const marketCostsColumns = [
    { key: 'Concepto', label: 'Concepto' },
    { key: 'Suministro', label: 'Suministro' },
    { key: 'Transmisión', label: 'Transmisión' },
    { key: 'Distribución', label: 'Distribución' },
    { key: 'CENACE', label: 'CENACE' },
    { key: 'Generación P', label: 'Generación P' },
    { key: 'Generación I', label: 'Generación I' },
    { key: 'SCnMEM', label: 'SCnMEM' },
    { key: 'Importe (MXN)', label: 'Importe (MXN)' },
  ];
  
  const paymentBreakdownColumns = [
    { key: 'Concepto', label: 'Concepto' },
    { key: 'Importe (MXN)', label: 'Importe (MXN)' },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <DataSection icon={<UserIcon/>} title="Información del Cliente" data={data.customerInfo} type="kv" />
        <DataSection icon={<InvoiceIcon/>} title="Resumen de Facturación" data={data.billingSummary} type="kv" />
      </div>
      
      <DataSection 
        icon={<ChartIcon/>} 
        title="Consumo Histórico" 
        data={data.historicalConsumption} 
        type="chart"
      >
        <ConsumptionChart data={data.historicalConsumption} />
      </DataSection>

      {data.consumptionDetails && data.consumptionDetails.length > 0 && (
        <DataSection icon={<TableIcon/>} title="Detalles del Consumo" data={data.consumptionDetails} type="table" columns={consumptionDetailsColumns} />
      )}
      
      {data.marketCosts && data.marketCosts.length > 0 && (
        <DataSection icon={<WrenchIcon/>} title="Costos del Mercado Eléctrico" data={data.marketCosts} type="table" columns={marketCostsColumns} />
      )}

      {data.paymentBreakdown && data.paymentBreakdown.length > 0 && (
        <DataSection icon={<MoneyIcon/>} title="Desglose del Importe a Pagar" data={data.paymentBreakdown} type="table" columns={paymentBreakdownColumns} />
      )}
    </div>
  );
};

export default BillDisplay;