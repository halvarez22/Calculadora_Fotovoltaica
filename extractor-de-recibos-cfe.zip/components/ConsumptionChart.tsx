import React from 'react';
import { HistoricalConsumptionData } from '../types';

const ConsumptionChart: React.FC<{ data: HistoricalConsumptionData[] }> = ({ data }) => {
  if (!data || data.length === 0) {
    return <p className="text-gray-400">No hay datos de consumo histórico disponibles.</p>;
  }

  const maxConsumption = Math.max(...data.map((d) => d.consumptionKWh), 0);
  const maxDemand = Math.max(...data.map((d) => d.demandKW), 0);

  // Use a combined max for a consistent y-axis if we were to plot them together,
  // but for separate bars, individual max is fine. We'll scale based on consumption max for simplicity.
  const yAxisMax = maxConsumption > 0 ? maxConsumption * 1.1 : 100; // Add 10% padding

  const reversedData = [...data].reverse();

  return (
    <div className="space-y-4">
        <div className="flex space-x-6 text-sm text-gray-400">
            <div className="flex items-center">
                <span className="w-4 h-4 rounded-sm bg-yellow-500 mr-2"></span>
                Consumo (KWh)
            </div>
            <div className="flex items-center">
                <span className="w-4 h-4 rounded-sm bg-gray-500 mr-2"></span>
                Demanda (KW)
            </div>
        </div>
      <div className="w-full h-72 pr-4 pl-0 py-4 relative flex items-end space-x-2 sm:space-x-4">
        {/* Y-Axis Labels */}
        <div className="h-full absolute left-0 top-0 flex flex-col justify-between text-xs text-gray-400 -translate-x-full pr-2 text-right">
            <span>{yAxisMax.toFixed(0)}</span>
            <span>{(yAxisMax * 0.5).toFixed(0)}</span>
            <span>0</span>
        </div>
        {/* Y-Axis Line */}
         <div className="absolute top-0 left-0 h-full w-px bg-gray-700"></div>


        {reversedData.map((item) => {
          const consumptionHeight = maxConsumption > 0 ? (item.consumptionKWh / yAxisMax) * 100 : 0;
          const demandHeight = maxDemand > 0 ? (item.demandKW / yAxisMax) * 100 : 0;

          return (
            <div key={item.period} className="flex-1 h-full flex flex-col justify-end items-center group">
              <div className="relative w-full h-full flex items-end justify-center gap-1">
                {/* Consumption Bar */}
                <div
                  className="w-1/2 bg-yellow-500 rounded-t-sm transition-all duration-300 ease-out"
                  style={{ height: `${consumptionHeight}%` }}
                  title={`Consumo: ${item.consumptionKWh} KWh`}
                ></div>
                {/* Demand Bar */}
                <div
                  className="w-1/2 bg-gray-500 rounded-t-sm transition-all duration-300 ease-out"
                  style={{ height: `${demandHeight}%` }}
                  title={`Demanda: ${item.demandKW} KW`}
                ></div>

                {/* Tooltip */}
                <div className="absolute bottom-full mb-2 w-40 p-2 bg-gray-800 text-white text-xs rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none transform -translate-x-1/2 left-1/2">
                  <p className="font-bold text-center border-b pb-1 mb-1">{item.period}</p>
                  <p className="flex items-center"><span className="w-2 h-2 rounded-full bg-yellow-500 mr-2"></span>Consumo: {item.consumptionKWh} KWh</p>
                  <p className="flex items-center"><span className="w-2 h-2 rounded-full bg-gray-500 mr-2"></span>Demanda: {item.demandKW} KW</p>
                  <div className="absolute left-1/2 -translate-x-1/2 top-full w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-gray-800"></div>
                </div>

              </div>
              <span className="mt-2 text-xs text-gray-400 font-medium">{item.period}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};


export default ConsumptionChart;