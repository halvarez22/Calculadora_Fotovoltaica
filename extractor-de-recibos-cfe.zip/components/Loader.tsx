import React from 'react';

interface LoaderProps {
  progress: number;
}

const Loader: React.FC<LoaderProps> = ({ progress }) => {
  const getStatusMessage = () => {
    if (progress < 40) return "Analizando estructura del documento...";
    if (progress < 85) return "Extrayendo datos con IA de Gemini...";
    return "Finalizando y compilando resultados...";
  };

  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <div className="relative w-20 h-20 mb-6">
        <div className="absolute inset-0 border-4 border-gray-700 rounded-full"></div>
        <div className="absolute inset-0 border-4 border-t-yellow-500 rounded-full animate-spin"></div>
        <div className="absolute inset-0 flex items-center justify-center text-lg font-bold text-yellow-500">
          {Math.round(progress)}%
        </div>
      </div>
      
      <div className="w-full max-w-md">
        <h3 className="text-xl font-semibold text-gray-200">Procesando tu recibo...</h3>
        <p className="mt-2 text-sm text-gray-400 h-5">{getStatusMessage()}</p>
        
        <div className="w-full bg-gray-700 rounded-full h-2.5 mt-4 overflow-hidden">
          <div
            className="bg-yellow-500 h-2.5 rounded-full transition-all duration-300 ease-linear"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default Loader;